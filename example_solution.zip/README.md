# Azure CLI
To handle deployment, Azure CLI is required

## Installing Azure CLI
### macOS
1. `brew update && brew install azure-cli`
