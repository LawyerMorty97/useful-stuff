import { onNewOrder } from "./onNewOrder";

module.exports = {
  onNewOrder
};
